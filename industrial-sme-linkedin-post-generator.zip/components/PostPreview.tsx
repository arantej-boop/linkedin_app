
import React, { useState, useEffect } from 'react';
import { PostData } from '../types';
import { LoadingSpinner } from './ui/LoadingSpinner';

interface PostPreviewProps {
  postData: PostData;
  imageDataUrl: string;
  isLoading: boolean;
  error: string | null;
}

const CopyIcon: React.FC<{ copied: boolean }> = ({ copied }) => copied ? (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
) : (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);


const LinkedInAction: React.FC<{ icon: React.ReactNode, label: string }> = ({ icon, label }) => (
    <div className="flex items-center space-x-2 text-slate-500 hover:bg-slate-100 p-2 rounded-md cursor-pointer transition-colors">
        {icon}
        <span className="font-medium text-sm">{label}</span>
    </div>
);

export const PostPreview: React.FC<PostPreviewProps> = ({ postData, imageDataUrl, isLoading, error }) => {
  const [copied, setCopied] = useState(false);

  const fullPostText = `${postData.postContent}\n\n${postData.hashtags.join(' ')}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullPostText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  
  const formattedContent = postData.postContent.split('\n').map((line, index) => (
    <React.Fragment key={index}>
      {line}
      <br />
    </React.Fragment>
  ));

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg relative min-h-[600px] flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-slate-700">LinkedIn Preview</h2>
        <button onClick={handleCopy} className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium py-2 px-3 rounded-lg transition">
          <CopyIcon copied={copied} />
          <span>{copied ? 'Copied!' : 'Copy Text'}</span>
        </button>
      </div>

      {error && <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-20 rounded-xl"><div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg max-w-sm text-center" role="alert"><strong className="font-bold">Error: </strong><span className="block sm:inline">{error}</span></div></div>}
      
      {isLoading && !error && (
        <div className="absolute inset-0 bg-white/80 flex flex-col items-center justify-center z-10 rounded-xl space-y-4">
            <LoadingSpinner />
            <p className="text-slate-600 font-medium">Generating content...</p>
        </div>
      )}

      <div className="border border-slate-200 rounded-lg p-4 flex-grow flex flex-col">
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-12 h-12 bg-sky-500 rounded-full flex items-center justify-center">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
             </svg>
          </div>
          <div>
            <p className="font-bold text-slate-800">Your Company Name</p>
            <p className="text-xs text-slate-500">1,234 followers • Promoted</p>
          </div>
        </div>

        <div className="text-sm text-slate-700 mb-2 whitespace-pre-wrap">
            {formattedContent}
            <p className="text-sky-700 font-medium mt-4">
                {postData.hashtags.join(' ')}
            </p>
        </div>

        <div className="mt-auto pt-2">
            <div className={`aspect-[16/9] w-full rounded-lg bg-slate-200 overflow-hidden ${!imageDataUrl && isLoading ? 'animate-pulse' : ''}`}>
               {imageDataUrl && <img src={imageDataUrl} alt="Generated for post" className="w-full h-full object-cover" />}
            </div>

            <div className="border-t border-slate-200 mt-3 pt-1 flex justify-around">
                <LinkedInAction icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.085a2 2 0 00-1.736.97l-2.7 4.5m7-10V5a2 2 0 00-2-2h-.085a2 2 0 00-1.736.97l-2.7 4.5m7 10l-3.5-7m0 0l-3.5 7m3.5-7H6.5" /></svg>} label="Like" />
                <LinkedInAction icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>} label="Comment" />
                <LinkedInAction icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>} label="Share" />
            </div>
        </div>

      </div>
    </div>
  );
};
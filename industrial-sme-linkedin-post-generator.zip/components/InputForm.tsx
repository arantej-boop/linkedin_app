
import React from 'react';
import { PostInput } from '../types';
import { TOPIC_OPTIONS, AUDIENCE_OPTIONS, TONE_OPTIONS } from '../constants';
import { CustomSelect } from './ui/CustomSelect';
import { Button } from './ui/Button';

interface InputFormProps {
  postInput: PostInput;
  setPostInput: React.Dispatch<React.SetStateAction<PostInput>>;
  onGenerate: (action: 'text' | 'image' | 'all') => void;
  isLoading: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ postInput, setPostInput, onGenerate, isLoading }) => {
  
  const handleInputChange = <K extends keyof PostInput,>(key: K, value: PostInput[K]) => {
    setPostInput(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-slate-700">1. Configure Your Post</h2>
      <div className="space-y-6">
        <div>
          <label htmlFor="topic" className="block text-sm font-medium text-slate-600 mb-1">Topic / Theme</label>
          <CustomSelect
            id="topic"
            value={postInput.topic}
            onChange={(e) => handleInputChange('topic', e.target.value)}
            options={TOPIC_OPTIONS}
            placeholder="Select a post topic"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="audience" className="block text-sm font-medium text-slate-600 mb-1">Target Audience</label>
            <CustomSelect
              id="audience"
              value={postInput.audience}
              onChange={(e) => handleInputChange('audience', e.target.value)}
              options={AUDIENCE_OPTIONS}
            />
          </div>
          <div>
            <label htmlFor="tone" className="block text-sm font-medium text-slate-600 mb-1">Tone of Voice</label>
            <CustomSelect
              id="tone"
              value={postInput.tone}
              onChange={(e) => handleInputChange('tone', e.target.value)}
              options={TONE_OPTIONS}
            />
          </div>
        </div>

        <div>
          <label htmlFor="keyInfo" className="block text-sm font-medium text-slate-600 mb-1">Key Information & Call to Action</label>
          <textarea
            id="keyInfo"
            rows={5}
            className="w-full px-3 py-2 text-slate-700 bg-slate-50 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500 transition"
            placeholder="e.g., We just launched our new CX-500 laser cutter. It's 20% faster and reduces waste by 15%. Visit our website to download the spec sheet."
            value={postInput.keyInfo}
            onChange={(e) => handleInputChange('keyInfo', e.target.value)}
            disabled={isLoading}
          />
        </div>
        
        <div className="border-t border-slate-200 pt-6">
           <h3 className="text-xl font-bold mb-4 text-slate-700">2. Generate Visuals</h3>
            <div>
              <label htmlFor="imagePrompt" className="block text-sm font-medium text-slate-600 mb-1">Image Prompt</label>
              <input
                type="text"
                id="imagePrompt"
                className="w-full px-3 py-2 text-slate-700 bg-slate-50 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500 transition"
                placeholder="e.g., A clean, modern factory floor with robotic arms."
                value={postInput.imagePrompt}
                onChange={(e) => handleInputChange('imagePrompt', e.target.value)}
                disabled={isLoading}
              />
            </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button onClick={() => onGenerate('all')} disabled={isLoading || !postInput.topic || !postInput.keyInfo} fullWidth>
                Generate Post & Image
            </Button>
            <Button onClick={() => onGenerate('text')} disabled={isLoading || !postInput.topic || !postInput.keyInfo} variant="secondary" fullWidth>
                Generate Text Only
            </Button>
        </div>
      </div>
    </div>
  );
};
